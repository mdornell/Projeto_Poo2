/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domain;

/**
 *
 * @author Marco
 */
public class Cliente {
        private int idCliente;
        private String nomeCliente;
        private String cpfCliente;
        private String rgCliente;
        private String emailCliente;
        private String celularCliente;
        private Endereco enderecoCliente;

    
        
        
}
