/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domain;

/**
 *
 * @author Marco
 */
public class Endereco {
        private String cepCliente;
        private String enderecoCliente;
        private int numEnderecoCliente;
        private String complEnderecoCliente;
        private String bairroCliete;
        private String cidadeCliente;
        private String estadpCliete;
}
