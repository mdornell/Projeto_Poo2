/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domain;

/**
 *
 * @author Marco
 */
public class Meterial {
    private int codigo;
    private String descricao;
    private double preco;
    private int qtdEstoque;
    private Fornecedor fornecedorMaterial;

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public int getQtdEstoque() {
        return qtdEstoque;
    }

    public void setQtdEstoque(int qtdEstoque) {
        this.qtdEstoque = qtdEstoque;
    }

    public Fornecedor getFornecedorMaterial() {
        return fornecedorMaterial;
    }

    public void setFornecedorMaterial(Fornecedor fornecedorMaterial) {
        this.fornecedorMaterial = fornecedorMaterial;
    }
            
}
